using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public GameObject asteroidPrefab;
    public float spawnRate; // Time interval between asteroid spawns
    public Transform[] spawnPoints;
    public int score = 0; // Player's score
    public bool isGameOver = false;
    public Text scoreText;
    public Text gameOverText;
    private int missedAsteroids = 0; // Total missed asteroids

    // Start is called before the first frame update
    void Start()
    {
        gameOverText.gameObject.SetActive(false); // Hide the Game Over text at the start

        // Retrieve the difficulty setting
        string difficulty = PlayerPrefs.GetString("Difficulty", "Medium");

        // Adjusts difficulty based on what you choose
        if (difficulty == "Easy")
        {
            spawnRate = 3f; // Asteroids spawn slower
        }
        else if (difficulty == "Hard")
        {
            spawnRate = 1f; // Asteroids spawn faster
        }
        else
        {
            spawnRate = 2f;
        }

        // Start spawning asteroids
        InvokeRepeating("SpawnAsteroid", 0f, spawnRate);
    }

    // Spawn an asteroid at a random position
    void SpawnAsteroid()
    {
        if (isGameOver) return; // Prevents the asteroid from spawning

        float randomX = Random.Range(-8f, 8f);
        Vector3 spawnPosition = new Vector3(randomX, 6f, 0);

        Instantiate(asteroidPrefab, spawnPosition, Quaternion.identity);
    }

    // Game over logic
    public void GameOver()
    {
        isGameOver = true;

        // Show the Game Over text
        gameOverText.gameObject.SetActive(true);

        // Stop spawning asteroids
        CancelInvoke("SpawnAsteroid");

        Debug.Log("Game Over! Final Score: " + score);
    }

    // Add score when an asteroid is destroyed
    public void AddScore(int points)
    {
        score += points;
        scoreText.text = "Score: " + score;
    }

    // Increment missed asteroid count
    public void IncrementMissedAsteroids()
    {
        missedAsteroids++;
        if (missedAsteroids >= 10) // If 10 asteroids are missed, end the game
        {
            GameOver();
        }
    }
}
