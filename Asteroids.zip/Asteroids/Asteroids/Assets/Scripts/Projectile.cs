using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 10f;
    public float lifetime = 3f;

    void Start()
    {
        Destroy(gameObject, lifetime);
    }

    void Update()
    {
        transform.Translate(Vector3.up * speed * Time.deltaTime);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Asteroid"))
        {
            GameController gameController = FindObjectOfType<GameController>();
            gameController.AddScore(10); 
            Destroy(collision.gameObject); // Destroys both the asteroid and the projectile when they collide
            Destroy(gameObject); 
        }
    }
}
