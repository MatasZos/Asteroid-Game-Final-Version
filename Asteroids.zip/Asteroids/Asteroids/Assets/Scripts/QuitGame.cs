using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class QuitGame : MonoBehaviour
{
    public void QuitToMainMenu()
    {
        // Load the main menu scene when Quit button is pressed
        SceneManager.LoadScene("MainMenu");
    }
}

