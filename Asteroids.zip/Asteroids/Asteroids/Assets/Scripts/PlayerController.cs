using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f; 
    public GameObject projectilePrefab;
    public Transform firePoint; 
    public float fireRate = 0.5f; 
    private float nextFireTime = 0f; 
    private AudioSource audioSource;

    private Camera mainCamera; // Main camera
    private float screenWidth;  // Width of the screen
    private float screenHeight; // Height of the screen

    void Start()
    {
        mainCamera = Camera.main; 
        screenWidth = mainCamera.orthographicSize * mainCamera.aspect;
        screenHeight = mainCamera.orthographicSize;
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        // Control the player
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(horizontalInput, verticalInput, 0) * moveSpeed * Time.deltaTime;
        transform.Translate(movement);

        // Make the spaceship wrap around the screen
        WrapAround();

        // Fire projectiles
        if (Input.GetKey(KeyCode.Space) && Time.time >= nextFireTime)
        {
            FireProjectile();
            nextFireTime = Time.time + fireRate; // Fire rate
        }
    }
    //Fires the projectile and audio plays when it is shot
    void FireProjectile()
    {
        Instantiate(projectilePrefab, firePoint.position, firePoint.rotation);

        if (audioSource != null)
        {
            audioSource.Play();
        }
    }

    // Method to make the spaceship wrap around the screen
    private void WrapAround()
    {
        // Get the spaceships current position
        Vector3 position = transform.position;

        // If the spaceship goes off the left or right edge, it will come back on the other side
        if (position.x > screenWidth)
        {
            position.x = -screenWidth; // Move to the left side
        }
        else if (position.x < -screenWidth)
        {
            position.x = screenWidth; // Move to the right side
        }

        // If the spaceship goes off the top or bottom edge, wrap it around
        if (position.y > screenHeight)
        {
            position.y = -screenHeight; // Move to the bottom
        }
        else if (position.y < -screenHeight)
        {
            position.y = screenHeight; // Move to the top
        }

        // Updates the position
        transform.position = position;
    }
}
