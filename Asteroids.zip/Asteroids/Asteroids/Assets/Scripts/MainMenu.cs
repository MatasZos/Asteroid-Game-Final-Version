using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // Start the game with the selected difficulty
    public void StartGame(string difficulty)
    {
        PlayerPrefs.SetString("Difficulty", difficulty);
        SceneManager.LoadScene("GameScene"); // Loads the game scene after you selected your difficulty
    }

    // Quit the game
    public void QuitGame()
    {
        Debug.Log("Quit Game clicked");
        Application.Quit(); 
    }
}
