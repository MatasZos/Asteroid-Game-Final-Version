using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    private static AudioManager instance;
    private AudioSource audioSource;

    void Awake()
    {
        if (instance == null)
        {
            // Doesnt destroy the background audio when the gameobject may disappear, meaning the audio will keep playing
            instance = this;
            DontDestroyOnLoad(gameObject); 
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        // Gets the audio source
        audioSource = GetComponent<AudioSource>();
        audioSource.Play();
    }
}

